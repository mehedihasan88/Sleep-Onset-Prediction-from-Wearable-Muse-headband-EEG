# V2 experiment summary

## Experiment identity
- Model: Dual-Path Spectral-Temporal CNN-GRU
- Date: 2026-11-01T12:02:04.368724+00:00
- Seed: 42
- Split: official Muse 412 train / 88 validation / 40 public test
- Trainable parameters: 143,777
- Training runtime: 40.44 minutes
- Device: cuda
- Python: 3.13.15
- PyTorch: 2.11.0+cu128

## Training outcomes
- Best epoch: 14
- Final epoch: 20
- Best validation W-bMAE: 41.5193 s
- Final validation W-bMAE: 44.5522 s
- Training loss at best epoch: 88.1206
- Final training loss: 81.4113
- Stop reason: early stopping after 6 non-improving epochs
- Peak GPU memory: 434.2 MB

## Best-checkpoint error analysis
- Plain MAE: 167.2021 s
- Unweighted bMAE: 91.2596 s
- Bin MAEs: 0_40=16.477, 40_90=35.731, 90_300=85.792, 300_600=227.038
- Bin biases: 0_40=11.531, 40_90=8.626, 90_300=-24.165, 300_600=-207.770
- Worst recording: 42 (54 windows,
  W-bMAE 102.927 s)
- Prediction standard deviation: 165.128 s
- Early/late MAE: 221.338 /
  112.996 s
- Recording-length/W-bMAE correlation: -0.027

## Feature fusion
- CNN norm: 3.1130
- Spectral embedding norm: 5.9471
- Spectral correction norm: 3.7033
- Correction/CNN ratio: 1.1896
- NaN/Inf count: 0
- Spectral MLP gradient norm: 212.171494
- Spectral projection gradient norm: 276.550629

## Elapsed-time-only diagnostic
- Train-fitted rule: y = 497.5067 + -0.2799 * elapsed_seconds
- Validation W-bMAE: 232.1005 s
- This diagnostic is not the submitted model.

## V1 comparison
- V1 validation W-bMAE: 43.0692 s
- V1 Codabench W-bMAE: 55.0472 s
- V2 values must only be compared on the same validation or Codabench split.

## Generalization limitations
- This is one seed on the official development split.
- The sealed cohort includes unseen sleepers and may shift substantially.
- Training backpropagates through 120-second chunks while inference retains
  state across a full recording.
