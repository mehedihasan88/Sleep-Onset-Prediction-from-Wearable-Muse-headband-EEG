# Diagnostic conclusions

1. Path B dominates the CNN; investigate projection regularization.
2. The largest absolute prediction bias is in `300_600`; prioritize
   calibration or sampling changes for that measured failure mode.
3. Compare the elapsed-only W-bMAE (232.100) with
   V2 before changing temporal context. If they are close, reduce reliance on
   elapsed time using recording-start augmentation or varied stream starts.

These are evidence-driven proposals only; no V3 changes were applied.
