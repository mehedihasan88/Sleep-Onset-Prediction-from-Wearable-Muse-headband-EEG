# V3-FullRecording experiment summary

## Controlled change
- Complete-recording BPTT replaces V2's independent 24-window training chunks.
- Architecture, seed, preprocessing, scaler mathematics, weighted L1, split,
  optimizer, scheduler, dropout, validation, and submission interface remain unchanged.
- Numerical exception: the CNN uses mixed precision, while the GRU, regression
  head, and loss use fp32. Full-recording fp16 backpropagation overflowed.
- Scaler was recomputed from 61,303 training-only windows;
  no V2 checkpoint or scaler was loaded.
- Parameters: 143,777 (V2: 143,777)

## Runtime
- Date: 2026-11-01T19:51:02.709294+00:00
- Device: cuda
- Runtime: 41.05 minutes
- Peak GPU memory: 351.3 MB
- Stop reason: early stopping after 6 non-improving epochs
- Best/final epoch: 12 / 18
- Optimizer steps at best epoch: 129
- Mean windows/step at best epoch: 475.22

## V2 versus V3
| Metric | V2 | V3 |
|---|---:|---:|
| Best validation W-bMAE | 41.5193 | 41.8295 |
| Validation bMAE | 91.2596 | 87.1632 |
| Validation plain MAE | 167.2021 | 154.3515 |
| 0_40 MAE | 16.477 | 14.796 |
| 40_90 MAE | 35.731 | 40.753 |
| 90_300 MAE | 85.792 | 87.930 |
| 300_600 MAE | 227.038 | 205.173 |
| Training duration (min) | 40.44 | 41.05 |
| Peak GPU memory (MB) | 434.2 | 351.3 |

- Early/late MAE: 195.577 / 113.072 s
- Improved bins: 0_40, 300_600
- Prediction mean/std: 259.734 /
  175.100 s
- Worst recording: 42

## Bias
- 0_40: V2 +11.531; V3 +5.832 s
- 40_90: V2 +8.626; V3 +6.070 s
- 90_300: V2 -24.165; V3 -22.105 s
- 300_600: V2 -207.770; V3 -183.931 s

## Decision
- Worth submitting: Not yet.
- A single seed is not statistical proof. Indivisible recordings also change
  optimizer-step count, which complicates attribution.
